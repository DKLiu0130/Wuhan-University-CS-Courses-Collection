int add(int x, int y) {
  return;
}

int main() {
  int a = 1;
  int b = 2;
  a = a + b * 3;
  if (a > 10) {
    b = a;
  } else {
    b = 0;
  }

  while (a < 100) {
    a = a + 1;
    if (a == 50) {
      break;
    }
    continue;
  }

  add(a, b);
  return;
}
