type token =
  | INT
  | VOID
  | IF
  | ELSE
  | WHILE
  | BREAK
  | CONTINUE
  | RETURN
  | PLUS
  | MINUS
  | MUL
  | DIV
  | MOD
  | EQ
  | NEQ
  | LT
  | GT
  | LE
  | GE
  | ANDAND
  | OROR
  | NOT
  | ASSIGN
  | SEMICOLON
  | COMMA
  | LPAREN
  | RPAREN
  | LBRACE
  | RBRACE
  | EOF
  | ID of (string)
  | NUMBER of (int)

val main :
  (Lexing.lexbuf  -> token) -> Lexing.lexbuf -> Ast.compunit
