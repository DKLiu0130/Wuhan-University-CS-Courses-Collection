%{
open Ast
%}

%token INT VOID IF ELSE WHILE BREAK CONTINUE RETURN
%token PLUS MINUS MUL DIV MOD
%token EQ NEQ LT GT LE GE
%token ANDAND OROR NOT
%token ASSIGN
%token SEMICOLON COMMA
%token LPAREN RPAREN LBRACE RBRACE EOF 

%token <string> ID
%token <int> NUMBER

%start main
%type <Ast.compunit> main

%%

main:
  compunit EOF { $1 } 

compunit:
  funcdef compunit_tail { $1 :: $2 }

compunit_tail:
  funcdef compunit_tail { $1 :: $2 }
|                   { [] }

funcdef:
  typ ID LPAREN param_list_opt RPAREN block
    { Function($1, $2, $4, $6) }

typ:
  INT { Int }
| VOID { Void }

param_list_opt:
  { [] }
| param_list  { $1 }

param_list:
  param { [$1] }
| param COMMA param_list { $1 :: $3 }

param:
  INT ID { Param(Int, $2) }

block:
  LBRACE stmt_list RBRACE { Block($2) }

stmt_list:
  { [] }
| stmt_list stmt { $2 :: $1 }  

stmt:
  block { $1 }  
| expr SEMICOLON { ExprStmt($1) }
| ID ASSIGN expr SEMICOLON { Assign($1, $3) }
| INT ID ASSIGN expr SEMICOLON { Decl(Int, $2, $4) }
| IF LPAREN expr RPAREN stmt { If($3, $5, None) }
| IF LPAREN expr RPAREN stmt ELSE stmt { If($3, $5, Some $7) }
| WHILE LPAREN expr RPAREN stmt { While($3, $5) }
| BREAK SEMICOLON { Break }
| CONTINUE SEMICOLON { Continue }
| RETURN SEMICOLON { Return None }  

expr:
  lorexpr { $1 }

lorexpr:
  landexpr { $1 }
| lorexpr OROR landexpr { BinaryOp(OrOr, $1, $3) }

landexpr:
  relexpr { $1 }
| landexpr ANDAND relexpr { BinaryOp(AndAnd, $1, $3) }

relexpr:
  addexpr { $1 }
| relexpr LT addexpr { BinaryOp(Lt, $1, $3) }
| relexpr GT addexpr { BinaryOp(Gt, $1, $3) }
| relexpr LE addexpr { BinaryOp(Le, $1, $3) }
| relexpr GE addexpr { BinaryOp(Ge, $1, $3) }
| relexpr EQ addexpr { BinaryOp(Eq, $1, $3) }
| relexpr NEQ addexpr { BinaryOp(Neq, $1, $3) }

addexpr:
  mulexpr { $1 }
| addexpr PLUS mulexpr { BinaryOp(Add, $1, $3) }
| addexpr MINUS mulexpr { BinaryOp(Sub, $1, $3) }

mulexpr:
  unaryexpr { $1 }
| mulexpr MUL unaryexpr { BinaryOp(Mul, $1, $3) }
| mulexpr DIV unaryexpr { BinaryOp(Div, $1, $3) }
| mulexpr MOD unaryexpr { BinaryOp(Mod, $1, $3) }

unaryexpr:
  primaryexpr { $1 }
| PLUS unaryexpr { UnaryOp(Plus, $2) }
| MINUS unaryexpr { UnaryOp(Minus, $2) }
| NOT unaryexpr { UnaryOp(Not, $2) }

primaryexpr:
  ID { Id($1) }
| NUMBER { Num($1) }
| LPAREN expr RPAREN { $2 }
| ID LPAREN expr_list_opt RPAREN { Call($1, $3) }

expr_list_opt:
  { [] }
| expr_list { $1 }

expr_list:
  expr { [$1] }
| expr COMMA expr_list { $1 :: $3 }
