type ty =
  | Int (* int *)
  | Void (* void *)

type unary_op =
  | Plus (* + *)
  | Minus (* - *)
  | Not (* ! *)

type binary_op =
  | Add
  | Sub
  | Mul
  | Div
  | Mod (* 算术运算符 *)
  | Lt
  | Gt
  | Le
  | Ge
  | Eq
  | Neq (* 比较运算符 *)
  | AndAnd
  | OrOr (* 逻辑运算符 *)

type expr =
  | Num of int (* 整数 *)
  | Id of string (* 标识符 *)
  | Call of string * expr list (* 函数调用 *)
  | Paren of expr (* 括号表达式 *)
  | UnaryOp of unary_op * expr (* 一元表达式 *)
  | BinaryOp of binary_op * expr * expr (* 二元表达式 *)

type param = Param of ty * string

type stmt =
  | Block of stmt list (* 块语句: { ... } *)
  | ExprStmt of expr (* 表达式语句 *)
  | Assign of string * expr (* 赋值: id = expr *)
  | Decl of ty * string * expr (* 变量声明: 类型, 标识符, 初始化表达式 *)
  | If of expr * stmt * stmt option (* if语句: 条件, 真分支, 假分支(可选) *)
  | While of expr * stmt (* while循环 *)
  | Break (* break *)
  | Continue (* continue *)
  | Return of expr option (* return (带返回值选项) *)

type funcdef = Function of ty * string * param list * stmt (* 返回类型, 函数名, 参数列表, 函数体 *)
type compunit = funcdef list
