{
open Parser
}

let whitespace = [' ' '\t' '\r' '\n']

rule read_token = parse
  | whitespace+ { read_token lexbuf }  (* 处理连续空白字符 *)
  
  (* 关键词 *)
  | "int"      { INT }
  | "void"     { VOID }
  | "if"       { IF }
  | "else"     { ELSE }
  | "while"    { WHILE }
  | "break"    { BREAK }
  | "continue" { CONTINUE }
  | "return"   { RETURN }

  (* 操作符和分隔符 *)
  | "+"  { PLUS }
  | "-"  { MINUS }
  | "*"  { MUL }
  | "/"  { DIV }
  | "%"  { MOD }
  | "==" { EQ }
  | "!=" { NEQ }
  | "<=" { LE }
  | ">=" { GE }
  | "<"  { LT }
  | ">"  { GT }
  | "&&" { ANDAND }
  | "||" { OROR }
  | "!"  { NOT }
  | "="  { ASSIGN }
  | ";"  { SEMICOLON }
  | ","  { COMMA }
  | "("  { LPAREN }
  | ")"  { RPAREN }
  | "{"  { LBRACE }
  | "}"  { RBRACE }

  (* 标识符与数字 *)
  | ['a'-'z''A'-'Z''_']['a'-'z''A'-'Z''0'-'9''_']* as str
      { ID str }

  | ['0'-'9']+ as num
      { NUMBER (int_of_string num) }

  (* 文件结束 *)
  | eof { EOF }  (* 添加 EOF 处理 *)
  
  (* 错误处理 *)
  | _ as c
      { failwith ("Unknown character: " ^ String.make 1 c) }
