type token =
  | INT
  | VOID
  | IF
  | ELSE
  | WHILE
  | BREAK
  | CONTINUE
  | RETURN
  | PLUS
  | MINUS
  | MUL
  | DIV
  | MOD
  | EQ
  | NEQ
  | LT
  | GT
  | LE
  | GE
  | ANDAND
  | OROR
  | NOT
  | ASSIGN
  | SEMICOLON
  | COMMA
  | LPAREN
  | RPAREN
  | LBRACE
  | RBRACE
  | EOF
  | ID of (string)
  | NUMBER of (int)

open Parsing;;
let _ = parse_error;;
# 2 "lib/parser.mly"
open Ast
# 40 "lib/parser.ml"
let yytransl_const = [|
  257 (* INT *);
  258 (* VOID *);
  259 (* IF *);
  260 (* ELSE *);
  261 (* WHILE *);
  262 (* BREAK *);
  263 (* CONTINUE *);
  264 (* RETURN *);
  265 (* PLUS *);
  266 (* MINUS *);
  267 (* MUL *);
  268 (* DIV *);
  269 (* MOD *);
  270 (* EQ *);
  271 (* NEQ *);
  272 (* LT *);
  273 (* GT *);
  274 (* LE *);
  275 (* GE *);
  276 (* ANDAND *);
  277 (* OROR *);
  278 (* NOT *);
  279 (* ASSIGN *);
  280 (* SEMICOLON *);
  281 (* COMMA *);
  282 (* LPAREN *);
  283 (* RPAREN *);
  284 (* LBRACE *);
  285 (* RBRACE *);
    0 (* EOF *);
    0|]

let yytransl_block = [|
  286 (* ID *);
  287 (* NUMBER *);
    0|]

let yylhs = "\255\255\
\001\000\002\000\004\000\004\000\003\000\005\000\005\000\006\000\
\006\000\008\000\008\000\009\000\007\000\010\000\010\000\011\000\
\011\000\011\000\011\000\011\000\011\000\011\000\011\000\011\000\
\011\000\012\000\013\000\013\000\014\000\014\000\015\000\015\000\
\015\000\015\000\015\000\015\000\015\000\016\000\016\000\016\000\
\017\000\017\000\017\000\017\000\018\000\018\000\018\000\018\000\
\019\000\019\000\019\000\019\000\020\000\020\000\021\000\021\000\
\000\000"

let yylen = "\002\000\
\002\000\002\000\002\000\000\000\006\000\001\000\001\000\000\000\
\001\000\001\000\003\000\002\000\003\000\000\000\002\000\001\000\
\002\000\004\000\005\000\005\000\007\000\005\000\002\000\002\000\
\002\000\001\000\001\000\003\000\001\000\003\000\001\000\003\000\
\003\000\003\000\003\000\003\000\003\000\001\000\003\000\003\000\
\001\000\003\000\003\000\003\000\001\000\002\000\002\000\002\000\
\001\000\001\000\003\000\004\000\000\000\001\000\001\000\003\000\
\002\000"

let yydefred = "\000\000\
\000\000\000\000\006\000\007\000\057\000\000\000\000\000\000\000\
\001\000\000\000\002\000\000\000\003\000\000\000\000\000\000\000\
\009\000\000\000\012\000\000\000\000\000\014\000\005\000\011\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\013\000\000\000\050\000\016\000\015\000\
\000\000\000\000\000\000\000\000\000\000\000\000\041\000\045\000\
\000\000\000\000\000\000\023\000\024\000\025\000\000\000\046\000\
\047\000\048\000\000\000\000\000\000\000\017\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\051\000\000\000\
\000\000\000\000\054\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\042\000\043\000\044\000\
\000\000\000\000\000\000\018\000\000\000\052\000\019\000\000\000\
\022\000\056\000\000\000\021\000"

let yydgoto = "\002\000\
\005\000\006\000\010\000\011\000\008\000\016\000\039\000\017\000\
\018\000\025\000\040\000\041\000\042\000\043\000\044\000\045\000\
\046\000\047\000\048\000\082\000\083\000"

let yysindex = "\005\000\
\003\255\000\000\000\000\000\000\000\000\019\000\003\255\254\254\
\000\000\003\255\000\000\019\255\000\000\038\255\017\255\032\255\
\000\000\028\255\000\000\046\255\038\255\000\000\000\000\000\000\
\026\255\030\255\050\255\057\255\065\255\073\255\075\255\086\255\
\086\255\086\255\086\255\000\000\023\255\000\000\000\000\000\000\
\082\255\088\255\090\255\040\000\014\255\074\255\000\000\000\000\
\091\255\086\255\086\255\000\000\000\000\000\000\085\255\000\000\
\000\000\000\000\104\255\086\255\086\255\000\000\086\255\086\255\
\086\255\086\255\086\255\086\255\086\255\086\255\086\255\086\255\
\086\255\086\255\086\255\086\255\105\255\108\255\000\000\089\255\
\114\255\113\255\000\000\090\255\040\000\014\255\014\255\014\255\
\014\255\014\255\014\255\074\255\074\255\000\000\000\000\000\000\
\117\255\072\255\072\255\000\000\086\255\000\000\000\000\111\255\
\000\000\000\000\072\255\000\000"

let yyrindex = "\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\150\000\000\000\
\000\000\150\000\000\000\000\000\000\000\124\255\000\000\000\000\
\000\000\127\255\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\185\255\000\000\000\000\000\000\
\000\000\013\255\037\255\018\000\249\254\128\255\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\109\255\000\000\
\000\000\000\000\000\000\000\000\131\255\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\132\255\000\000\000\000\080\255\026\000\196\255\210\255\224\255\
\238\255\252\255\010\000\147\255\166\255\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\062\255\
\000\000\000\000\000\000\000\000"

let yygindex = "\000\000\
\000\000\000\000\159\000\160\000\000\000\000\000\149\000\152\000\
\000\000\000\000\179\255\221\255\000\000\114\000\115\000\251\000\
\235\255\225\255\000\000\000\000\077\000"

let yytablesize = 321
let yytable = "\059\000\
\056\000\057\000\058\000\003\000\004\000\001\000\031\000\031\000\
\031\000\031\000\031\000\031\000\031\000\031\000\077\000\078\000\
\031\000\031\000\009\000\031\000\104\000\105\000\071\000\072\000\
\080\000\081\000\026\000\012\000\027\000\108\000\028\000\029\000\
\030\000\031\000\032\000\033\000\026\000\026\000\015\000\026\000\
\097\000\094\000\095\000\096\000\014\000\060\000\019\000\034\000\
\061\000\092\000\093\000\035\000\021\000\022\000\036\000\037\000\
\038\000\027\000\020\000\049\000\027\000\027\000\020\000\027\000\
\020\000\081\000\020\000\020\000\020\000\020\000\020\000\020\000\
\026\000\022\000\027\000\050\000\028\000\029\000\030\000\031\000\
\032\000\033\000\051\000\020\000\073\000\074\000\075\000\020\000\
\052\000\020\000\020\000\020\000\020\000\034\000\032\000\033\000\
\053\000\035\000\054\000\022\000\028\000\037\000\038\000\028\000\
\028\000\062\000\028\000\034\000\063\000\064\000\061\000\035\000\
\100\000\076\000\107\000\055\000\038\000\049\000\049\000\049\000\
\049\000\049\000\049\000\049\000\049\000\049\000\049\000\049\000\
\049\000\049\000\079\000\098\000\049\000\049\000\099\000\049\000\
\038\000\038\000\101\000\102\000\103\000\038\000\038\000\038\000\
\038\000\038\000\038\000\038\000\038\000\004\000\008\000\038\000\
\038\000\010\000\038\000\039\000\039\000\053\000\055\000\007\000\
\039\000\039\000\039\000\039\000\039\000\039\000\039\000\039\000\
\023\000\013\000\039\000\039\000\024\000\039\000\040\000\040\000\
\084\000\106\000\085\000\040\000\040\000\040\000\040\000\040\000\
\040\000\040\000\040\000\000\000\000\000\040\000\040\000\000\000\
\040\000\049\000\049\000\049\000\049\000\049\000\049\000\049\000\
\049\000\049\000\049\000\049\000\049\000\049\000\000\000\000\000\
\049\000\036\000\036\000\036\000\036\000\036\000\036\000\036\000\
\036\000\000\000\000\000\036\000\036\000\000\000\036\000\037\000\
\037\000\037\000\037\000\037\000\037\000\037\000\037\000\000\000\
\000\000\037\000\037\000\000\000\037\000\032\000\032\000\032\000\
\032\000\032\000\032\000\032\000\032\000\000\000\000\000\032\000\
\032\000\000\000\032\000\033\000\033\000\033\000\033\000\033\000\
\033\000\033\000\033\000\000\000\000\000\033\000\033\000\000\000\
\033\000\034\000\034\000\034\000\034\000\034\000\034\000\034\000\
\034\000\000\000\000\000\034\000\034\000\000\000\034\000\035\000\
\035\000\035\000\035\000\035\000\035\000\035\000\035\000\000\000\
\000\000\035\000\035\000\000\000\035\000\029\000\029\000\000\000\
\000\000\029\000\029\000\000\000\029\000\030\000\030\000\000\000\
\000\000\030\000\030\000\000\000\030\000\065\000\066\000\067\000\
\068\000\069\000\070\000\086\000\087\000\088\000\089\000\090\000\
\091\000"

let yycheck = "\035\000\
\032\000\033\000\034\000\001\001\002\001\001\000\014\001\015\001\
\016\001\017\001\018\001\019\001\020\001\021\001\050\000\051\000\
\024\001\025\001\000\000\027\001\098\000\099\000\009\001\010\001\
\060\000\061\000\001\001\030\001\003\001\107\000\005\001\006\001\
\007\001\008\001\009\001\010\001\024\001\025\001\001\001\027\001\
\076\000\073\000\074\000\075\000\026\001\023\001\030\001\022\001\
\026\001\071\000\072\000\026\001\025\001\028\001\029\001\030\001\
\031\001\021\001\027\001\030\001\024\001\025\001\001\001\027\001\
\003\001\101\000\005\001\006\001\007\001\008\001\009\001\010\001\
\001\001\028\001\003\001\026\001\005\001\006\001\007\001\008\001\
\009\001\010\001\026\001\022\001\011\001\012\001\013\001\026\001\
\024\001\028\001\029\001\030\001\031\001\022\001\009\001\010\001\
\024\001\026\001\024\001\028\001\021\001\030\001\031\001\024\001\
\025\001\024\001\027\001\022\001\021\001\020\001\026\001\026\001\
\024\001\023\001\004\001\030\001\031\001\009\001\010\001\011\001\
\012\001\013\001\014\001\015\001\016\001\017\001\018\001\019\001\
\020\001\021\001\027\001\027\001\024\001\025\001\027\001\027\001\
\009\001\010\001\025\001\027\001\024\001\014\001\015\001\016\001\
\017\001\018\001\019\001\020\001\021\001\000\000\027\001\024\001\
\025\001\027\001\027\001\009\001\010\001\027\001\027\001\001\000\
\014\001\015\001\016\001\017\001\018\001\019\001\020\001\021\001\
\020\000\010\000\024\001\025\001\021\000\027\001\009\001\010\001\
\063\000\101\000\064\000\014\001\015\001\016\001\017\001\018\001\
\019\001\020\001\021\001\255\255\255\255\024\001\025\001\255\255\
\027\001\009\001\010\001\011\001\012\001\013\001\014\001\015\001\
\016\001\017\001\018\001\019\001\020\001\021\001\255\255\255\255\
\024\001\014\001\015\001\016\001\017\001\018\001\019\001\020\001\
\021\001\255\255\255\255\024\001\025\001\255\255\027\001\014\001\
\015\001\016\001\017\001\018\001\019\001\020\001\021\001\255\255\
\255\255\024\001\025\001\255\255\027\001\014\001\015\001\016\001\
\017\001\018\001\019\001\020\001\021\001\255\255\255\255\024\001\
\025\001\255\255\027\001\014\001\015\001\016\001\017\001\018\001\
\019\001\020\001\021\001\255\255\255\255\024\001\025\001\255\255\
\027\001\014\001\015\001\016\001\017\001\018\001\019\001\020\001\
\021\001\255\255\255\255\024\001\025\001\255\255\027\001\014\001\
\015\001\016\001\017\001\018\001\019\001\020\001\021\001\255\255\
\255\255\024\001\025\001\255\255\027\001\020\001\021\001\255\255\
\255\255\024\001\025\001\255\255\027\001\020\001\021\001\255\255\
\255\255\024\001\025\001\255\255\027\001\014\001\015\001\016\001\
\017\001\018\001\019\001\065\000\066\000\067\000\068\000\069\000\
\070\000"

let yynames_const = "\
  INT\000\
  VOID\000\
  IF\000\
  ELSE\000\
  WHILE\000\
  BREAK\000\
  CONTINUE\000\
  RETURN\000\
  PLUS\000\
  MINUS\000\
  MUL\000\
  DIV\000\
  MOD\000\
  EQ\000\
  NEQ\000\
  LT\000\
  GT\000\
  LE\000\
  GE\000\
  ANDAND\000\
  OROR\000\
  NOT\000\
  ASSIGN\000\
  SEMICOLON\000\
  COMMA\000\
  LPAREN\000\
  RPAREN\000\
  LBRACE\000\
  RBRACE\000\
  EOF\000\
  "

let yynames_block = "\
  ID\000\
  NUMBER\000\
  "

let yyact = [|
  (fun _ -> failwith "parser")
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'compunit) in
    Obj.repr(
# 22 "lib/parser.mly"
               ( _1 )
# 289 "lib/parser.ml"
               : Ast.compunit))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'funcdef) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'compunit_tail) in
    Obj.repr(
# 25 "lib/parser.mly"
                        ( _1 :: _2 )
# 297 "lib/parser.ml"
               : 'compunit))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'funcdef) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'compunit_tail) in
    Obj.repr(
# 28 "lib/parser.mly"
                        ( _1 :: _2 )
# 305 "lib/parser.ml"
               : 'compunit_tail))
; (fun __caml_parser_env ->
    Obj.repr(
# 29 "lib/parser.mly"
                    ( [] )
# 311 "lib/parser.ml"
               : 'compunit_tail))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 5 : 'typ) in
    let _2 = (Parsing.peek_val __caml_parser_env 4 : string) in
    let _4 = (Parsing.peek_val __caml_parser_env 2 : 'param_list_opt) in
    let _6 = (Parsing.peek_val __caml_parser_env 0 : 'block) in
    Obj.repr(
# 33 "lib/parser.mly"
    ( Function(_1, _2, _4, _6) )
# 321 "lib/parser.ml"
               : 'funcdef))
; (fun __caml_parser_env ->
    Obj.repr(
# 36 "lib/parser.mly"
      ( Int )
# 327 "lib/parser.ml"
               : 'typ))
; (fun __caml_parser_env ->
    Obj.repr(
# 37 "lib/parser.mly"
       ( Void )
# 333 "lib/parser.ml"
               : 'typ))
; (fun __caml_parser_env ->
    Obj.repr(
# 40 "lib/parser.mly"
  ( [] )
# 339 "lib/parser.ml"
               : 'param_list_opt))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'param_list) in
    Obj.repr(
# 41 "lib/parser.mly"
              ( _1 )
# 346 "lib/parser.ml"
               : 'param_list_opt))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'param) in
    Obj.repr(
# 44 "lib/parser.mly"
        ( [_1] )
# 353 "lib/parser.ml"
               : 'param_list))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'param) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'param_list) in
    Obj.repr(
# 45 "lib/parser.mly"
                         ( _1 :: _3 )
# 361 "lib/parser.ml"
               : 'param_list))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 48 "lib/parser.mly"
         ( Param(Int, _2) )
# 368 "lib/parser.ml"
               : 'param))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 1 : 'stmt_list) in
    Obj.repr(
# 51 "lib/parser.mly"
                          ( Block(_2) )
# 375 "lib/parser.ml"
               : 'block))
; (fun __caml_parser_env ->
    Obj.repr(
# 54 "lib/parser.mly"
  ( [] )
# 381 "lib/parser.ml"
               : 'stmt_list))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'stmt_list) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'stmt) in
    Obj.repr(
# 55 "lib/parser.mly"
                 ( _2 :: _1 )
# 389 "lib/parser.ml"
               : 'stmt_list))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'block) in
    Obj.repr(
# 58 "lib/parser.mly"
        ( _1 )
# 396 "lib/parser.ml"
               : 'stmt))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'expr) in
    Obj.repr(
# 59 "lib/parser.mly"
                 ( ExprStmt(_1) )
# 403 "lib/parser.ml"
               : 'stmt))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 3 : string) in
    let _3 = (Parsing.peek_val __caml_parser_env 1 : 'expr) in
    Obj.repr(
# 60 "lib/parser.mly"
                           ( Assign(_1, _3) )
# 411 "lib/parser.ml"
               : 'stmt))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 3 : string) in
    let _4 = (Parsing.peek_val __caml_parser_env 1 : 'expr) in
    Obj.repr(
# 61 "lib/parser.mly"
                               ( Decl(Int, _2, _4) )
# 419 "lib/parser.ml"
               : 'stmt))
; (fun __caml_parser_env ->
    let _3 = (Parsing.peek_val __caml_parser_env 2 : 'expr) in
    let _5 = (Parsing.peek_val __caml_parser_env 0 : 'stmt) in
    Obj.repr(
# 62 "lib/parser.mly"
                             ( If(_3, _5, None) )
# 427 "lib/parser.ml"
               : 'stmt))
; (fun __caml_parser_env ->
    let _3 = (Parsing.peek_val __caml_parser_env 4 : 'expr) in
    let _5 = (Parsing.peek_val __caml_parser_env 2 : 'stmt) in
    let _7 = (Parsing.peek_val __caml_parser_env 0 : 'stmt) in
    Obj.repr(
# 63 "lib/parser.mly"
                                       ( If(_3, _5, Some _7) )
# 436 "lib/parser.ml"
               : 'stmt))
; (fun __caml_parser_env ->
    let _3 = (Parsing.peek_val __caml_parser_env 2 : 'expr) in
    let _5 = (Parsing.peek_val __caml_parser_env 0 : 'stmt) in
    Obj.repr(
# 64 "lib/parser.mly"
                                ( While(_3, _5) )
# 444 "lib/parser.ml"
               : 'stmt))
; (fun __caml_parser_env ->
    Obj.repr(
# 65 "lib/parser.mly"
                  ( Break )
# 450 "lib/parser.ml"
               : 'stmt))
; (fun __caml_parser_env ->
    Obj.repr(
# 66 "lib/parser.mly"
                     ( Continue )
# 456 "lib/parser.ml"
               : 'stmt))
; (fun __caml_parser_env ->
    Obj.repr(
# 67 "lib/parser.mly"
                   ( Return None )
# 462 "lib/parser.ml"
               : 'stmt))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'lorexpr) in
    Obj.repr(
# 70 "lib/parser.mly"
          ( _1 )
# 469 "lib/parser.ml"
               : 'expr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'landexpr) in
    Obj.repr(
# 73 "lib/parser.mly"
           ( _1 )
# 476 "lib/parser.ml"
               : 'lorexpr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'lorexpr) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'landexpr) in
    Obj.repr(
# 74 "lib/parser.mly"
                        ( BinaryOp(OrOr, _1, _3) )
# 484 "lib/parser.ml"
               : 'lorexpr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'relexpr) in
    Obj.repr(
# 77 "lib/parser.mly"
          ( _1 )
# 491 "lib/parser.ml"
               : 'landexpr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'landexpr) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'relexpr) in
    Obj.repr(
# 78 "lib/parser.mly"
                          ( BinaryOp(AndAnd, _1, _3) )
# 499 "lib/parser.ml"
               : 'landexpr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'addexpr) in
    Obj.repr(
# 81 "lib/parser.mly"
          ( _1 )
# 506 "lib/parser.ml"
               : 'relexpr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'relexpr) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'addexpr) in
    Obj.repr(
# 82 "lib/parser.mly"
                     ( BinaryOp(Lt, _1, _3) )
# 514 "lib/parser.ml"
               : 'relexpr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'relexpr) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'addexpr) in
    Obj.repr(
# 83 "lib/parser.mly"
                     ( BinaryOp(Gt, _1, _3) )
# 522 "lib/parser.ml"
               : 'relexpr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'relexpr) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'addexpr) in
    Obj.repr(
# 84 "lib/parser.mly"
                     ( BinaryOp(Le, _1, _3) )
# 530 "lib/parser.ml"
               : 'relexpr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'relexpr) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'addexpr) in
    Obj.repr(
# 85 "lib/parser.mly"
                     ( BinaryOp(Ge, _1, _3) )
# 538 "lib/parser.ml"
               : 'relexpr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'relexpr) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'addexpr) in
    Obj.repr(
# 86 "lib/parser.mly"
                     ( BinaryOp(Eq, _1, _3) )
# 546 "lib/parser.ml"
               : 'relexpr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'relexpr) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'addexpr) in
    Obj.repr(
# 87 "lib/parser.mly"
                      ( BinaryOp(Neq, _1, _3) )
# 554 "lib/parser.ml"
               : 'relexpr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'mulexpr) in
    Obj.repr(
# 90 "lib/parser.mly"
          ( _1 )
# 561 "lib/parser.ml"
               : 'addexpr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'addexpr) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'mulexpr) in
    Obj.repr(
# 91 "lib/parser.mly"
                       ( BinaryOp(Add, _1, _3) )
# 569 "lib/parser.ml"
               : 'addexpr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'addexpr) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'mulexpr) in
    Obj.repr(
# 92 "lib/parser.mly"
                        ( BinaryOp(Sub, _1, _3) )
# 577 "lib/parser.ml"
               : 'addexpr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'unaryexpr) in
    Obj.repr(
# 95 "lib/parser.mly"
            ( _1 )
# 584 "lib/parser.ml"
               : 'mulexpr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'mulexpr) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'unaryexpr) in
    Obj.repr(
# 96 "lib/parser.mly"
                        ( BinaryOp(Mul, _1, _3) )
# 592 "lib/parser.ml"
               : 'mulexpr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'mulexpr) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'unaryexpr) in
    Obj.repr(
# 97 "lib/parser.mly"
                        ( BinaryOp(Div, _1, _3) )
# 600 "lib/parser.ml"
               : 'mulexpr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'mulexpr) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'unaryexpr) in
    Obj.repr(
# 98 "lib/parser.mly"
                        ( BinaryOp(Mod, _1, _3) )
# 608 "lib/parser.ml"
               : 'mulexpr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'primaryexpr) in
    Obj.repr(
# 101 "lib/parser.mly"
              ( _1 )
# 615 "lib/parser.ml"
               : 'unaryexpr))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'unaryexpr) in
    Obj.repr(
# 102 "lib/parser.mly"
                 ( UnaryOp(Plus, _2) )
# 622 "lib/parser.ml"
               : 'unaryexpr))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'unaryexpr) in
    Obj.repr(
# 103 "lib/parser.mly"
                  ( UnaryOp(Minus, _2) )
# 629 "lib/parser.ml"
               : 'unaryexpr))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'unaryexpr) in
    Obj.repr(
# 104 "lib/parser.mly"
                ( UnaryOp(Not, _2) )
# 636 "lib/parser.ml"
               : 'unaryexpr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 107 "lib/parser.mly"
     ( Id(_1) )
# 643 "lib/parser.ml"
               : 'primaryexpr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : int) in
    Obj.repr(
# 108 "lib/parser.mly"
         ( Num(_1) )
# 650 "lib/parser.ml"
               : 'primaryexpr))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 1 : 'expr) in
    Obj.repr(
# 109 "lib/parser.mly"
                     ( _2 )
# 657 "lib/parser.ml"
               : 'primaryexpr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 3 : string) in
    let _3 = (Parsing.peek_val __caml_parser_env 1 : 'expr_list_opt) in
    Obj.repr(
# 110 "lib/parser.mly"
                                 ( Call(_1, _3) )
# 665 "lib/parser.ml"
               : 'primaryexpr))
; (fun __caml_parser_env ->
    Obj.repr(
# 113 "lib/parser.mly"
  ( [] )
# 671 "lib/parser.ml"
               : 'expr_list_opt))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'expr_list) in
    Obj.repr(
# 114 "lib/parser.mly"
            ( _1 )
# 678 "lib/parser.ml"
               : 'expr_list_opt))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'expr) in
    Obj.repr(
# 117 "lib/parser.mly"
       ( [_1] )
# 685 "lib/parser.ml"
               : 'expr_list))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'expr) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'expr_list) in
    Obj.repr(
# 118 "lib/parser.mly"
                       ( _1 :: _3 )
# 693 "lib/parser.ml"
               : 'expr_list))
(* Entry main *)
; (fun __caml_parser_env -> raise (Parsing.YYexit (Parsing.peek_val __caml_parser_env 0)))
|]
let yytables =
  { Parsing.actions=yyact;
    Parsing.transl_const=yytransl_const;
    Parsing.transl_block=yytransl_block;
    Parsing.lhs=yylhs;
    Parsing.len=yylen;
    Parsing.defred=yydefred;
    Parsing.dgoto=yydgoto;
    Parsing.sindex=yysindex;
    Parsing.rindex=yyrindex;
    Parsing.gindex=yygindex;
    Parsing.tablesize=yytablesize;
    Parsing.table=yytable;
    Parsing.check=yycheck;
    Parsing.error_function=parse_error;
    Parsing.names_const=yynames_const;
    Parsing.names_block=yynames_block }
let main (lexfun : Lexing.lexbuf -> token) (lexbuf : Lexing.lexbuf) =
   (Parsing.yyparse yytables 1 lexfun lexbuf : Ast.compunit)
