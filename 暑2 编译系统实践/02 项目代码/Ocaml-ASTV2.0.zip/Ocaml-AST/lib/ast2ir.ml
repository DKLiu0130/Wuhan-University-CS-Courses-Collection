(* 需要柯同学完成 *)
open Ast

let ast2myir (input_ast : compunit) : unit = ()
