(* 这部分由谢同学完成 *)

let register_allocation () : unit = ()
