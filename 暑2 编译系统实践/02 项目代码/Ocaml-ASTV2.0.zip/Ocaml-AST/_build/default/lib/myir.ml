(* 柯同学完成 *)
type ty =
  | Int
  | Void (* 基本类型 *)

type binop =
  | Add
  | Sub
  | Mul
  | Div
  | Rem (* 二元操作符 *)

type icmp_cond =
  | Eq
  | Ne
  | Ge
  | Le
  | Gt
  | Lt (* 比较条件 *)

type ident = string (* 标识符（变量） *)
type idlabel = int (*块号*)

type value =
  | Var of ident (* 变量引用 *)
  | Literal of int (* 整数字面量 *)

type instruction =
  (* 返回指令 *)
  | Ret of value option (* ret <value> 或 ret void *)
  (* 分支指令 *)
  | Br of value * idlabel * idlabel (* br <cond>, <iftrue>, <iffalse> *)
  | Jump of idlabel (* jump <dest> *)
  (* 二元运算 *)
  | Binop of binop * ident * value * value (* <result> = binop <op1> <op2> *)
  (* 内存分配 *)
  | Alloca of ident (* <result> = alloca *)
  (* 内存操作 *)
  | Store of value * ident (* store <value>, *<pointer> *)
  | Load of ident * ident (* <result> = load *<pointer> *)
  (* 比较操作 *)
  | Icmp of icmp_cond * ident * value * value (* <result> = icmp <cond> <op1> <op2> *)
  (* Phi节点 *)
  | Phi of ident * (value * ident) list (* <result> = phi [<val0>,<label0>], ... *)
  (* 函数调用 *)
  | Call of ty * int * value list option
  (* <result>? = call <ty>(int/void) <name>(<args>) *)
  (* 逻辑非 *)
  | Not of ident * value (* <result> = not <op1> *)
