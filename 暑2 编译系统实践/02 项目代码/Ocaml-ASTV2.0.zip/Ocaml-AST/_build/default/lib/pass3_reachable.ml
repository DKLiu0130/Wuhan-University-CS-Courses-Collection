(* 这部分由郑同学完成 *)
let pass3 () : unit = ()
