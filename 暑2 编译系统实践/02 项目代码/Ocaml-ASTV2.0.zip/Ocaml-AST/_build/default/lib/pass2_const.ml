(* 这部分由郑同学完成 *)
let pass2 () : unit = ()
