(* 需要柯同学完成 *)

let ast2myir () : unit = ()
