lib/pass2_const.ml:
