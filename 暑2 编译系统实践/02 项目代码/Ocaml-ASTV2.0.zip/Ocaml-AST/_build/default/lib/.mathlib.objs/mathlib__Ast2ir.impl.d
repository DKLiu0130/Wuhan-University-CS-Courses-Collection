lib/ast2ir.ml:
