lib/data_structure.ml: List Myir
