lib/pass3_reachable.ml:
