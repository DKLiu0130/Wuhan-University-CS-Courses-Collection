lib/pass1_cycle.ml:
