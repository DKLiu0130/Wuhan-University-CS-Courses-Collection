(* 有需要可以每个人都可以添加相关的函数，如果需要更改或者新增数据结构，请与我联系 *)

open Myir

type pre_Key = int * int

type tb_Whole =
  { name : string
  ; used_number : int
  ; records : (int * int * int option) list (* index * block * value *)
  }

type info_Block =
  { id_num : int
  ; statements : instruction list
  ; definition_table : string list
  }

let pre_graph : pre_Key list ref = ref []
let block : info_Block list ref = ref []
let analyse_table : tb_Whole list ref = ref []
let insert_pregraph (key : pre_Key) : unit = pre_graph := !pre_graph @ [ key ]

let get_pregraph_succ (id : int) : int list =
  List.fold_left
    (fun acc (from_, to_) -> if from_ = id then to_ :: acc else acc)
    []
    !pre_graph
;;

let get_pregraph_pred (id : int) : int list =
  List.fold_left
    (fun acc (from_, to_) -> if to_ = id then from_ :: acc else acc)
    []
    !pre_graph
;;

let insert_block (id : int) : unit =
  let new_block = { id_num = id; statements = []; definition_table = [] } in
  block := !block @ [ new_block ]
;;

let get_block (id : int) : info_Block =
  try List.find (fun b -> b.id_num = id) !block with
  | Not_found -> failwith ("Block with id " ^ string_of_int id ^ " not found.")
;;

let replace_block (updated : info_Block) : unit =
  block := List.map (fun b -> if b.id_num = updated.id_num then updated else b) !block
;;

let add_block_stmts (id : int) (stmts : instruction list) : unit =
  let b = get_block id in
  let updated = { b with statements = b.statements @ stmts } in
  replace_block updated
;;

let add_block_stmt (id : int) (s : instruction) : unit =
  let b = get_block id in
  let updated = { b with statements = b.statements @ [ s ] } in
  replace_block updated
;;

let add_block_def (id : int) (def : string) : unit =
  let b = get_block id in
  let updated = { b with definition_table = def :: b.definition_table } in
  replace_block updated
;;

let check_block_def (id : int) (def : string) : bool =
  let b = get_block id in
  List.mem def b.definition_table
;;

let insert_analyse_defs (name : string) (block_id : int) (value : int option) : unit =
  let new_item = { name; used_number = 1; records = [ 0, block_id, value ] } in
  analyse_table := !analyse_table @ [ new_item ]
;;

let insert_analyse_usage (name : string) (block_id : int) (value : int option) : unit =
  let rev_table = List.rev !analyse_table in
  let rec find_and_update acc = function
    | [] -> !analyse_table (* 没有匹配项，不改动 *)
    | item :: rest ->
      if item.name = name
      then (
        let updated =
          { item with
            used_number = item.used_number + 1
          ; records = item.records @ [ item.used_number, block_id, value ]
          }
        in
        List.rev acc @ [ updated ] @ rest)
      else find_and_update (item :: acc) rest
  in
  analyse_table := find_and_update [] rev_table
;;

let delay_analyse_bottomup (defs : string list) : unit =
  let rev_table = List.rev !analyse_table in
  let filtered = List.filter (fun item -> not (List.mem item.name defs)) rev_table in
  analyse_table := List.rev filtered
;;
