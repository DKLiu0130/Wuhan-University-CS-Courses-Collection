
int calculate(int p1, int p2, int p3, int p4, int p5, int p6, int p7, int p8) {
    return p1 + p2 - p3 * p4 / p5 + p6 - p7 * p8;
}
int main() {
    int res = calculate(1, 2, 3, 4, 5, 6, 7, 8);
    return res;
}


