
int main() {
    int a = 10;
    int b = 5;
    int c = 0;
    int d = 0;
    if ((d = a + b) > 10) {
        c = 11;
    }
    return c;
}


