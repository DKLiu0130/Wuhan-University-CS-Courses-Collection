
int main() {
    int i = 0;
    int sum = 0;
    while ((i < 5) && (i != 3)) {
        sum = sum + i;
        i = i + 1;
    }
    return sum;
}


