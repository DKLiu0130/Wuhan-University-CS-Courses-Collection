int main() {
    int a = 10;
    int b = 3;
    int c;
    c = a % b; // 1
    return c;
}


