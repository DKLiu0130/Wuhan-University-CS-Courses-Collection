
int main() {
    int t = 1;
    int f = 0;
    int c;
    c = t || f; // 1
    return c;
}


