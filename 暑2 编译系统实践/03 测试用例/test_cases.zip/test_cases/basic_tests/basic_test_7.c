int main() {
    int a = 10;
    int b = 5;
    int c;
    c = a + b * 2; // 10 + 10 = 20
    return c;
}


