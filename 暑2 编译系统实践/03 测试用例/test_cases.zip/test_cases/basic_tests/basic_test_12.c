
int main() {
    int x = -10;
    int y = -3;
    int c;
    c = x % y; // -1
    return c;
}


