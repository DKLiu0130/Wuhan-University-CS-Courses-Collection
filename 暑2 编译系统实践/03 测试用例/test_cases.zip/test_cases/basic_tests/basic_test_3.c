int main() {
    int a = 10;
    int b = 5;
    int c;
    c = a * b; // 50
    return c;
}


