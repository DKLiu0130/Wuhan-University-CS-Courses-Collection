
int main() {
    int x = -10;
    int y = -3;
    int c;
    c = x * y; // 30
    return c;
}


