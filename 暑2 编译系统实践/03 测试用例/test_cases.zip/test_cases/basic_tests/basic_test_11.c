int main() {
    int x = -10;
    int y = -3;
    int c;
    c = x / y; // 3
    return c;
}


