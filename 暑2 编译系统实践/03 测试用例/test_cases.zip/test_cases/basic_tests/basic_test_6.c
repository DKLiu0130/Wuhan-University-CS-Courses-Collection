
int main() {
    int a = 10;
    int b = 5;
    int c;
    c = (a + b) * (a - b); // 15 * 5 = 75
    return c;
}


