
int main() {
    int a = 10;
    int b = 20;
    int c = 0;
    int sum = 0;
    if ((c = a + b) > 25) {
        sum = sum + 1;
    } else {
        sum = sum + 2;
    }
    return sum;
}


