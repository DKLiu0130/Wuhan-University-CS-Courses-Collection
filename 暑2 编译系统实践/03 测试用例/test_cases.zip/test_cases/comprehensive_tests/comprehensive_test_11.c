int main() {
    int x = 1, y = 2, z = 3;
    int result = 0;
    result = (x + y) * z - (x / y);
    return result;
}


