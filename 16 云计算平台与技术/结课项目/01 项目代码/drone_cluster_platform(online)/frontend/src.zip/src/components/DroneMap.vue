<!-- frontend/src/components/DroneMap.vue -->

<script setup>
import 'leaflet/dist/leaflet.css'; // 导入 Leaflet 的 CSS
import { LMap, LTileLayer, LMarker, LIcon, LTooltip } from '@vue-leaflet/vue-leaflet';
import { ref, onMounted, onUnmounted, watch } from 'vue';
import { useAuthStore } from '../stores/auth'; // 假设你的认证 store 在这个路径
import { useRouter } from 'vue-router';      // 路由，用于跳转登录页
import { api } from '../api/auth';            // 假设你的 API 客户端在这个路径

// 定义组件的 props，用于接收父组件传递的 selectedDroneId
const props = defineProps({
  drones: {
    type: Array,
    default: () => [] // 默认为空数组，防止 undefined
  },
  selectedDroneId: {
    type: [String, Number, null],
    default: null
  }
});
// 定义组件的 emits，用于向父组件发出事件，更新 selectedDroneId
const emit = defineEmits(['update:selectedDroneId']);

const authStore = useAuthStore();
const router = useRouter();

const zoom = ref(13); // 地图默认缩放级别
const center = ref([31.2304, 121.4737]); // 地图默认中心坐标 (上海)

let fetchInterval = null; // 用于存储定时器 ID，以便在组件卸载时清除

/**
 * 根据无人机电池电量和飞行状态获取对应颜色的图标 URL。
 * 使用 Leaflet Color Markers (https://github.com/pointhi/leaflet-color-markers)
 * 参数 drone 是后端返回的 telemetry 对象
 */
const getDroneIcon = (battery_level, is_flying) => {
  let iconColor = 'blue'; // 默认蓝色图标

  if (battery_level !== undefined && battery_level !== null) {
    if (battery_level <= 20) iconColor = 'red';      // 低电量显示红色
    else if (battery_level <= 50) iconColor = 'orange'; // 中电量显示橙色
    else iconColor = 'green';                         // 充足电量显示绿色
  }

  // 如果无人机没有在飞行，则显示灰色图标，这会覆盖上面的颜色，表示非活动状态
  if (!is_flying) {
    iconColor = 'grey'; 
  }

  // 返回自定义图标的 URL
  return `https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-${iconColor}.png`;
};

/**
 * 从后端获取所有无人机的最新遥测数据。
 */
const fetchLatestTelemetry = async () => {
  // 如果用户未认证，则重定向到登录页
  if (!authStore.isAuthenticated) {
    router.push('/login');
    return;
  }
  try {
    // 调用后端 API 获取数据
    const response = await api.get('/api/telemetry/latest_all', {
      headers: { Authorization: `Bearer ${authStore.token}` } // 附加 JWT token
    });
    
    // 后端返回的数据结构是 { "telemetry_data": [...] }
    const newDrones = response.data.telemetry_data;
    if (newDrones && newDrones.length > 0) {
        drones.value = newDrones; // 更新无人机数据列表

        // 如果有选中的无人机，将地图中心设置到该无人机的位置
        if (props.selectedDroneId) {
            const selected = newDrones.find(d => d.drone_id === props.selectedDroneId);
            if (selected) {
                // 使用 parseFloat 确保坐标是数字类型，用于 Leaflet
                center.value = [parseFloat(selected.current_latitude), parseFloat(selected.current_longitude)];
            }
        } else if (drones.value.length === 0 && newDrones.length > 0) {
            // 如果是首次加载且当前无人机列表为空，将地图中心设到第一个无人机的位置
            center.value = [parseFloat(newDrones[0].current_latitude), parseFloat(newDrones[0].current_longitude)];
        }
    } else {
        drones.value = []; // 如果没有数据，清空列表，避免显示旧数据
    }
  } catch (error) {
    console.error('Error fetching latest telemetry:', error);
    // 处理认证失败，清空认证数据并重定向到登录页
    if (error.response && error.response.status === 401) {
      authStore.clearAuthData();
      router.push('/login');
    }
  }
};

/**
 * 当用户点击地图上的无人机标记时触发。
 * 发出事件通知父组件更新 selectedDroneId，并更新地图中心。
 */
const selectDrone = (drone) => {
  emit('update:selectedDroneId', drone.drone_id);
  center.value = [parseFloat(drone.current_latitude), parseFloat(drone.current_longitude)];
};

// 组件挂载时，加载数据并设置定时器
onMounted(() => {
  // fetchLatestTelemetry();
  // fetchInterval = setInterval(fetchLatestTelemetry, 3000); // 每 3 秒刷新一次遥测数据
});

// 组件卸载时，清除定时器以避免内存泄漏
onUnmounted(() => {
  // if (fetchInterval) {
  //   clearInterval(fetchInterval);
  // }
});

// 监听 selectedDroneId props 的变化，如果变化则更新地图中心
watch(() => props.selectedDroneId, (newId) => {
  if (newId) {
    const selected = drones.value.find(d => d.drone_id === newId);
    if (selected) {
      center.value = [parseFloat(selected.current_latitude), parseFloat(selected.current_longitude)];
    }
  }
});
</script>

<template>
  <div style="height: 500px; width: 100%; border-radius: 8px; overflow: hidden;">
    <l-map ref="map" v-model:zoom="zoom" :center="center" :use-global-leaflet="false">
      <!-- OpenStreetMap 地图图层 -->
      <l-tile-layer
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        layer-type="base"
        name="OpenStreetMap"
      ></l-tile-layer>

      <!-- 遍历 drones 列表，为每架无人机添加一个标记 -->
      <l-marker 
        v-for="drone in drones" 
        :key="drone.drone_id" 
        :lat-lng="[parseFloat(drone.current_latitude), parseFloat(drone.current_longitude)]"
        @click="selectDrone(drone)"
      >
        <!-- 使用自定义图标，根据电池电量和飞行状态改变图标的颜色 -->
        <l-icon :icon-url="getDroneIcon(drone.battery_level, drone.is_flying)" :icon-size="[32, 32]" :icon-anchor="[16, 32]"></l-icon>
        
        <!-- 鼠标悬停显示 tooltip，提供无人机详细信息 -->
        <l-tooltip>
          <p>ID: {{ drone.drone_id }}</p>
          <p>模式: {{ drone.flight_mode }} {{ drone.is_flying ? '(飞行中)' : '(降落)' }}</p>
          <!-- 安全检查：确保字段存在且有效，防止显示 'NaN%' 或 'null m/s' -->
          <p>电池: {{ drone.battery_level !== undefined && drone.battery_level !== null ? drone.battery_level + '%' : 'N/A' }}</p>
          <p>速度: {{ drone.speed !== undefined && drone.speed !== null ? parseFloat(drone.speed).toFixed(1) + ' m/s' : 'N/A' }}</p>
          <p>高度: {{ drone.current_altitude !== undefined && drone.current_altitude !== null ? parseFloat(drone.current_altitude).toFixed(1) + ' m' : 'N/A' }}</p>
          <p>经度: {{ parseFloat(drone.current_longitude).toFixed(4) }}</p>
          <p>纬度: {{ parseFloat(drone.current_latitude).toFixed(4) }}</p>
          <p v-if="drone.error_message" style="color: red;">错误: {{ drone.error_message }}</p>
          <p>更新于: {{ drone.updated_at ? new Date(drone.updated_at).toLocaleTimeString() : 'N/A' }}</p>
        </l-tooltip>
      </l-marker>
    </l-map>
  </div>
</template>

<style scoped>
/* 可以根据需要添加样式 */
</style>