<!-- frontend/src/views/HomeView.vue -->
<script setup>
import { ref, onMounted } from 'vue';
import { useAuthStore } from '../stores/auth';
import { useRouter } from 'vue-router';
import { api } from '../api/auth';
import DroneMap from '../components/DroneMap.vue'; // 已导入，无需修改

const authStore = useAuthStore();
const router = useRouter();

// 已有代码：用户数、无人机总数、指令总数
const userCount = ref(0);
const droneCount = ref(0);
const commandCount = ref(0);
// 新增：存储无人机实时遥测数据（核心！地图需要这个数据）
const drones = ref([]); // 初始化空数组，避免 undefined
const selectedDroneOnMap = ref(null); // 保持不变

// --- 新增：获取无人机实时遥测数据的函数 ---
const fetchDronesTelemetry = async () => {
  try {
    const response = await api.get('/api/drones/telemetry', {
      headers: { Authorization: `Bearer ${authStore.token}` }
    });
    // 假设后端返回格式：{ data: [{ id: 'drone1', latitude: 30.123, longitude: 120.456, ... }, ...] }
    drones.value = response.data.data || []; // 确保默认是空数组，避免 undefined
  } catch (error) {
    console.error('Error fetching drones telemetry:', error);
    drones.value = []; // 错误时也赋空数组，防止渲染崩溃
    if (error.response && error.response.status === 401) {
      authStore.clearAuthData();
      router.push('/login'); // 权限失效时跳转登录页
    }
  }
};



// 获取用户数量
const fetchUserCount = async () => {
    try {
        const response = await api.get('/api/users/count', {
            headers: { Authorization: `Bearer ${authStore.token}` }
        });
        userCount.value = response.data.count;
    } catch (error) {
        console.error('Error fetching user count:', error);
        if (error.response && error.response.status === 401) {
            authStore.clearAuthData();
            router.push('/login');
        }
    }
};

// 获取无人机数量
const fetchDroneCount = async () => {
    try {
        const response = await api.get('/api/drones/count', { // 假设你有一个 /api/drones/count 路由
            headers: { Authorization: `Bearer ${authStore.token}` }
        });
        droneCount.value = response.data.count;
    } catch (error) {
        console.error('Error fetching drone count:', error);
        if (error.response && error.response.status === 401) {
            authStore.clearAuthData();
            router.push('/login');
        }
    }
};

// 获取指令数量
const fetchCommandCount = async () => {
    try {
        const response = await api.get('/api/commands/count', { // 假设你有一个 /api/commands/count 路由
            headers: { Authorization: `Bearer ${authStore.token}` }
        });
        commandCount.value = response.data.count;
    } catch (error) {
        console.error('Error fetching command count:', error);
        if (error.response && error.response.status === 401) {
            authStore.clearAuthData();
            router.push('/login');
        }
    }
};

// --- 修改 onMounted：添加获取无人机数据的调用 ---
onMounted(async () => {
  // 并行获取所有数据
  await Promise.all([
    fetchUserCount(),
    fetchDroneCount(),
    fetchCommandCount(),
    fetchDronesTelemetry() // 新增：获取无人机实时数据
  ]);
});
</script>

<template>
  <div class="home">
    <div class="header">
      <h1>Dashboard</h1>
    </div>

    <div class="stats-cards">
      <div class="card">
        <h3>Registered Users</h3>
        <p>{{ userCount }}</p>
      </div>
      <div class="card">
        <h3>Total Drones</h3>
        <p>{{ droneCount }}</p>
      </div>
      <div class="card">
        <h3>Pending Commands</h3>
        <p>{{ commandCount }}</p>
      </div>
    </div>

    <!-- Live Drone Map Section -->
    <div class="map-section">
  <h2>Live Drone Map</h2>
  <!-- 传递无人机数据给 DroneMap，并保持双向绑定 -->
  <DroneMap 
    v-model:selectedDroneId="selectedDroneOnMap" 
    :drones="drones"  
  /> 
  <p v-if="selectedDroneOnMap">Selected Drone ID: {{ selectedDroneOnMap }}</p>
</div>

    <!-- 可以添加更多 Dashboard 内容，例如最近的系统日志、命令列表等 -->
    <div class="recent-activities">
      <h2>Recent Activities</h2>
      <!-- ... 这里可以放一个最新的命令列表或事件日志 ... -->
      <p>No recent activities to display yet.</p>
    </div>
  </div>
</template>

