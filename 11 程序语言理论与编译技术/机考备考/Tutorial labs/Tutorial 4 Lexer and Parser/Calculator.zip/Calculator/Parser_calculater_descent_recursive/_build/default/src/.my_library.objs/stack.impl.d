src/stack.ml:
