.text
.global main
main:
	li a1, 10
	slli a2, a1, 3
	mv a0, a2
	ret

