.text
.global main
main:
	li a1, 5
	li a2, 3
	li a3, 2
	madd a1, a2, a3, a1
	mv a0, a1
	ret

