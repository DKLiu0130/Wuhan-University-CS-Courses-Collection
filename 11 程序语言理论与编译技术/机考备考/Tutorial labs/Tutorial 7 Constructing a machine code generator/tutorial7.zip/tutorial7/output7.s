.text
.global main
main:
	li a1, 10
	li a2, -2
	add a3, a1, a2
	mv a0, a3
	ret

